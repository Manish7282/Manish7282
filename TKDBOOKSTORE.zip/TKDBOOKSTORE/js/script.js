let searchform=document.querySelector('.search-form');
document.querySelector('#search-button').onclick=()=>{
    searchform.classList.toggle('active');
    shoppingcart.classList.remove('active');
    loginform.classList.remove('active');
    navbar.classList.remove('active');
};

let shoppingcart=document.querySelector('.shopping-cart');
document.querySelector('#cart-button').onclick=()=>{
    shoppingcart.classList.toggle('active');
    searchform.classList.remove('active')
    loginform.classList.remove('active');
    navbar.classList.remove('active');
};
let loginform=document.querySelector('.login-form');
document.querySelector('#login-button').onclick=()=>{
    loginform.classList.toggle('active');
    searchform.classList.remove('active')
    shoppingcart.classList.remove('active');
    navbar.classList.remove('active');
};
let navbar=document.querySelector('.navbar');
document.querySelector('#menu-button').onclick=()=>{
    navbar.classList.toggle('active');
    searchform.classList.remove('active')
    shoppingcart.classList.remove('active');
    loginform.classList.remove('active');
};


window.onscroll=()=>{
    searchform.classList.remove('active')
    shoppingcart.classList.remove('active');
    loginform.classList.remove('active');
    navbar.classList.remove('active');
};
//add to cart code
// let cart = JSON.parse(localStorage.getItem("cart")) || []; // पहले से सेव किया हुआ डेटा लोड करें
// const cartContainer = document.querySelector(".shopping-cart");
// const totalPriceElement = document.querySelector(".total");

// document.querySelectorAll(".add-to-cart").forEach(button => {
//     button.addEventListener("click", (e) => {
//         e.preventDefault();
//         let itemId = button.getAttribute("data-id");
//         let itemName = button.getAttribute("data-name");
//         let itemPrice = parseInt(button.getAttribute("data-price"));

//         let existingItem = cart.find(item => item.id === itemId);
//         if (existingItem) {
//             existingItem.quantity++;
//         } else {
//             cart.push({ id: itemId, name: itemName, price: itemPrice, quantity: 1 });
//         }

//         localStorage.setItem("cart", JSON.stringify(cart));
//         updateCartUI();
//     });
// });

// function updateCartUI() {
//     cartContainer.innerHTML = ""; 
//     let total = 0;

//     cart.forEach(item => {
//         let cartItem = document.createElement("div");
//         cartItem.classList.add("box");
//         cartItem.innerHTML = `
//             <h3>${item.name}</h3>
//             <p>₹${item.price} x ${item.quantity}</p>
//             <button class="remove-item" data-id="${item.id}">Remove</button>
//         `;
//         cartContainer.appendChild(cartItem);
//         total += item.price * item.quantity;
//     });

//     totalPriceElement.innerText = `Total: ₹${total}`;
//     attachRemoveEvent();
// }

// function attachRemoveEvent() {
//     document.querySelectorAll(".remove-item").forEach(button => {
//         button.addEventListener("click", () => {
//             let itemId = button.getAttribute("data-id");
//             cart = cart.filter(item => item.id !== itemId);
//             localStorage.setItem("cart", JSON.stringify(cart));
//             updateCartUI();
//         });
//     });
// }

// updateCartUI(); 

document.addEventListener("DOMContentLoaded", function () {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    const cartContainer = document.querySelector(".shopping-cart");
    const totalPriceElement = document.querySelector(".total");
    const buyNowButton = document.getElementById("cart-buy-now");

    // ✅ "Add to Cart" Function
    document.querySelectorAll(".add-to-cart").forEach(button => {
        button.addEventListener("click", (e) => {
            e.preventDefault();
            let itemId = button.getAttribute("data-id");
            let itemName = button.getAttribute("data-name");
            let itemPrice = parseInt(button.getAttribute("data-price"));

            let existingItem = cart.find(item => item.id === itemId);
            if (existingItem) {
                existingItem.quantity++;
            } else {
                cart.push({ id: itemId, name: itemName, price: itemPrice, quantity: 1 });
            }

            localStorage.setItem("cart", JSON.stringify(cart));
            updateCartUI();
            alert(`${itemName} added to cart! 🛒`);
        });
    });

    // ✅ Cart UI Update Function
    function updateCartUI() {
        cartContainer.innerHTML = ""; 
        let total = 0;

        cart.forEach(item => {
            let cartItem = document.createElement("div");
            cartItem.classList.add("box");
            cartItem.innerHTML = `
                <h3>${item.name}</h3>
                <p>₹${item.price} x ${item.quantity}</p>
                <button class="remove-item" data-id="${item.id}">Remove</button>
            `;
            cartContainer.appendChild(cartItem);
            total += item.price * item.quantity;
        });

        totalPriceElement.innerText = `Total: ₹${total}`;
        attachRemoveEvent();

        // ✅ अगर Cart में आइटम हैं तो "Buy Now" बटन दिखाओ
        buyNowButton.style.display = cart.length > 0 ? "block" : "none";
    }

    // ✅ Remove Item from Cart Function
    function attachRemoveEvent() {
        document.querySelectorAll(".remove-item").forEach(button => {
            button.addEventListener("click", () => {
                let itemId = button.getAttribute("data-id");
                cart = cart.filter(item => item.id !== itemId);
                localStorage.setItem("cart", JSON.stringify(cart));
                updateCartUI();
            });
        });
    }

    // ✅ "Buy Now" बटन Event Listener
    buyNowButton.addEventListener("click", function () {
        if (cart.length > 0) {
            localStorage.setItem("checkout", JSON.stringify(cart));
            window.location.href = "checkout.html"; // Checkout Page पर Redirect करो
        } else {
            alert("Your cart is empty!");
        }
    });

    updateCartUI();
});



// search section 
document.addEventListener("DOMContentLoaded", function () {
    let searchBox = document.querySelector("#search-box");

    if (!searchBox) {
        console.error("❌ ERROR: Search box not found! Check ID in HTML.");
        return;
    }

    searchBox.addEventListener("keyup", function () {
        let query = this.value.toLowerCase();
        let products = document.querySelectorAll("#products .box");
        let found = false;

        products.forEach(product => {
            let productName = product.querySelector("h3");
            if (!productName) {
                console.error("⚠️ WARNING: No <h3> found inside .box");
                return;
            }

            productName = productName.innerText.toLowerCase();
            if (productName.includes(query)) {
                product.style.display = "block";
                found = true;
            } else {
                product.style.display = "none";
            }
        });

        // ❌ अगर कुछ नहीं मिला, तो "Items Not Found" मैसेज दिखाओ
        let notFoundMessage = document.getElementById("not-found");
        if (!notFoundMessage) {
            notFoundMessage = document.createElement("p");
            notFoundMessage.id = "not-found";
            notFoundMessage.style.color = "red";
            notFoundMessage.style.fontSize = "18px";
            notFoundMessage.style.textAlign = "center";
            notFoundMessage.innerText = "❌ Items Not Found!";
            document.getElementById("products").appendChild(notFoundMessage);
        }
        notFoundMessage.style.display = found ? "none" : "block";
    });
});

// Buy now
document.querySelectorAll(".buy-now").forEach(button => {
    button.addEventListener("click", (e) => {
        e.preventDefault();
        let itemId = button.getAttribute("data-id");
        let itemName = button.getAttribute("data-name");
        let itemPrice = parseInt(button.getAttribute("data-price"));

        // ✅ Checkout Data Set करो
        let checkoutItem = [{ id: itemId, name: itemName, price: itemPrice, quantity: 1 }];
        localStorage.setItem("checkout", JSON.stringify(checkoutItem));

        // ✅ Checkout Page पर Redirect करो
        window.location.href = "checkout.html";
    });
});








