document.getElementById("address-form").addEventListener("submit", function (e) {
    e.preventDefault();

    let name = document.getElementById("name").value;
    let phone = document.getElementById("phone").value;
    let address = document.getElementById("address").value;
    let pincode = document.getElementById("pincode").value;
    let city = document.getElementById("city").value;
    let state = document.getElementById("state").value;

    let checkoutItems = JSON.parse(localStorage.getItem("checkout")) || [];
    
    if (checkoutItems.length === 0) {
        alert("❌ No items to checkout.");
        return;
    }

    let orderDetails = {
        name: name,
        phone: phone,
        address: address,
        pincode: pincode,
        city: city,
        state: state,
        items: checkoutItems
    };

    localStorage.setItem("order", JSON.stringify(orderDetails));
    localStorage.removeItem("checkout"); // ✅ Checkout Clear करो
    localStorage.removeItem("cart"); // ✅ Cart भी Clear करो

    alert("🎉 Order Confirmed! Your details have been saved.");
    window.location.href = "index.html";
});
